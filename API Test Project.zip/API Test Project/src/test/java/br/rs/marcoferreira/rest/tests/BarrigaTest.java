package br.rs.marcoferreira.rest.tests;

import br.rs.marcoferreira.rest.core.BaseTest;
import org.junit.Before;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class BarrigaTest extends BaseTest { //Extendido BaseTest da classe CORE. Vai colocar todos os atributos estáticos no RestAssured que foram configurados na classe BaseTest

    private String TOKEN;

    @Before //Vai instanciar 1x antes de cada 1 dos testes. Vai fazer o login e vai pro método depois
    public void login() {
        Map<String, String> login = new HashMap<>();
        login.put("email", "marco.scariot@gmail.com"); //Criar a prória conta em https://seubarriga.wcaquino.me/cadastro
        login.put("senha", "102030");

        //Extrair o token
        TOKEN = given()
                .body(login)

                .when()
                .post("/signin")

                .then()
                .statusCode(200) //Resposta de statusCode de OK
                .extract().path("token");
    }

    @Test
    public void naoDeveAcessarAPISemToken() {
        given()

                .when()
                .get("/contas")//Recurso utilizado

                .then()
                .statusCode(401) //Resposta de statusCode de não autorizado
        ;
    }

    @Test
    public void deveIncluirContaComSucesso() {
        Map<String, String> login = new HashMap<>();
        login.put("email", "marco.scariot@gmail.com"); //Criar a prória conta em https://seubarriga.wcaquino.me/cadastro
        login.put("senha", "102030");

        //Extrair o token
        String token = given()
                .body(login)

                .when()
                .post("/signin")

                .then()
                .statusCode(200) //Resposta de statusCode de OK para inserção
                .extract().path("token");

        given()
                .header("Authorization", "JWT " + token) //APIs mais recentes seria "bearer" ao invés de JWT
                .body("{\"nome\":\"conta qualquer\"}") //Conta que será incluída

                .when()
                .post("/contas")

                .then()
                .statusCode(201) //Resposta OK de inclusão
        ;
    }

    @Test
    public void deveAlterarContaComSucesso() {
        given()
                .header("Authorization", "JWT " + TOKEN) //APIs mais recentes seria "bearer" ao invés de JWT
                .body("{\"nome\":\"conta alterada\"}") //Novo nome da conta

                .when()
                .put("/contas/1098451") //id da conta que se quer excluir. Nesse exemplo eu olhei na web e botei fixo

                .then()
                .log().all()
                .statusCode(200) //Resposta OK de alteração
                .body("nome", is("conta alterada"))
        ;
    }

    @Test
    public void naoDeveIncluirContaComNomeRepetido() {
        given()
                .header("Authorization", "JWT " + TOKEN) //APIs mais recentes seria "bearer" ao invés de JWT
                .body("{\"nome\":\"conta alterada\"}") //Novo nome da conta

                .when()
                .post("/contas/") //Onde vai ser o post

                .then()
                .statusCode(400) //Resposta NÃO OK de inclusão
                .body("error", is("Já existe uma conta com esse nome!"))
        ;
    }

    @Test
    public void deveInserirMovimentacaoComSucesso() {
        Movimentacao mov = new Movimentacao(); //Instanciou a clase Movimentação
        //Serão inseridos todos os valores obrigatórios aqui para a transação
        mov.setConta_id(1098451);
//        mov.getUsuario_id();
        mov.setDescricao("Descricao da movimentacao");
        mov.setEnvolvido("Envolvido na movimentacao");
        mov.setTipo("REC"); //Receita
        mov.setData_transacao("01/01/2000");
        mov.setData_pagamento("10/05/2010");
        mov.setValor(100f); //f indica Float
        mov.setStatus(true); //True = conta paga

        given()
                .header("Authorization", "JWT " + TOKEN) //APIs mais recentes seria "bearer" ao invés de JWT
                .body(mov) //Como já está subentendido que o contentType é JSON então esse objeto vai ser convertido para um JSON

                .when()
                .post("/transacoes/") //Onde vai ser o post

                .then()
                .statusCode(201) //Resposta de statusCode de OK para inserção
        ;
    }

    @Test
    public void deveValidarCamposObrigatoriosMovimentacao() {
        given()
                .header("Authorization", "JWT " + TOKEN) //APIs mais recentes seria "bearer" ao invés de JWT
                .body("{}") //Enviando objeto vazio (todos os valores vinham encapsulados neste objeto)

                .when()
                .post("/transacoes/") //Onde vai ser o post

                .then()
                .statusCode(400) //Resposta de statusCode de NÃO OK para inserção
                .body("$", hasSize(8)) //8 validações de campos que são obrigatórios. É bom colocar a validação de tamanho para que, caso num futuro venham mais, o cenário não deve aceitar.
                .body("msg", hasItems(
                        "Data da Movimentação é obrigatório",
                        "Data do pagamento é obrigatório",
                        "Descrição é obrigatório",
                        "Interessado é obrigatório",
                        "Valor é obrigatório",
                        "Valor deve ser um número",
                        "Conta é obrigatório",
                        "Situação é obrigatório"
                ))
        ;
    }

    @Test
    public void NaoDeveInserirMovimentacaoComDataFutura() {
        Movimentacao mov = getMovimentacaoValida();
        mov.setData_transacao("13/01/2077"); //Data futura

        given()
                .header("Authorization", "JWT " + TOKEN) //APIs mais recentes seria "bearer" ao invés de JWT
                .body(mov) //Como já está subentendido que o contentType é JSON então esse objeto vai ser convertido para um JSON

                .when()
                .post("/transacoes/") //Onde vai ser o post

                .then()
                .statusCode(400) //Resposta NÃO OK de inclusão
                .body("$", hasSize(1)) //Deve retornar apenas 1 erro
                .body("msg", hasItem("Data da Movimentação deve ser menor ou igual à data atual")) //Uso do hasItem pois podem haver várias mensagems nesse array que retorna
        ;
    }

    @Test
    public void NaoDeveRemoverContaComMovimentacao() {
        given()
                .header("Authorization", "JWT " + TOKEN) //APIs mais recentes seria "bearer" ao invés de JWT

                .when()
                .delete("/Contas/1098451") //Onde vai ser o delete e a conta a remover

                .then()
                .statusCode(500) //Resposta de sem sucesso
                .body("constraint",is ("transacoes_conta_id_foreign")) //Esse foi o retorno do log quando tentei excluir uma conta com movimentação, então vou validar
        ;
    }

    @Test
    public void deveCalcularSaldoContas() {
        given()
                .header("Authorization", "JWT " + TOKEN) //APIs mais recentes seria "bearer" ao invés de JWT

                .when()
                .get("/saldo") //Onde vai ser o get

                .then()
                .statusCode(200)
                .body("find{it.conta_id == 1098451}.saldo",is ("100.00")) //Verifico se na conta em questão temos o valor string em questão
        ;
    }

    @Test
    public void deveRemoverMovimentacao() {
        given()
                .header("Authorization", "JWT " + TOKEN) //APIs mais recentes seria "bearer" ao invés de JWT

                .when()
                .delete("/transacoes/1026928") //Onde vai ser o delete e qual ID da transação

                .then()
                .statusCode(204)
        ;
    }

    //Método auxiliar
    private Movimentacao getMovimentacaoValida() {
        Movimentacao mov = new Movimentacao(); //Instanciou a clase Movimentação
        //Serão inseridos todos os valores obrigatórios aqui para a transação
        mov.setConta_id(1098451);
//        mov.getUsuario_id();
        mov.setDescricao("Descricao da movimentacao");
        mov.setEnvolvido("Envolvido na movimentacao");
        mov.setTipo("REC"); //Receita
        mov.setData_transacao("01/01/2000");
        mov.setData_pagamento("10/05/2010");
        mov.setValor(100f); //f indica Float
        mov.setStatus(true); //True = conta paga
        return mov; //Vai retonar a movimentação, aqui denominada apenas mov
    }
}
